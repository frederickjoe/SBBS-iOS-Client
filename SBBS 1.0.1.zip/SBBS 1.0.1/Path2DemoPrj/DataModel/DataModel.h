//
//  DataModel.h
//  虎踞龙盘BBS
//
//  Created by 张晓波 on 4/28/12.
//  Copyright (c) 2012 Ethan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Topic.h"
#import "Board.h"
#import "User.h"
#import "Mail.h"
#import "Notification.h"
#import "Attachment.h"
@interface DataModel : NSObject

@end
