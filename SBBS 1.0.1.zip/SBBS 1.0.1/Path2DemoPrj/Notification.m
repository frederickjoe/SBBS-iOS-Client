//
//  Notification.m
//  虎踞龙蟠
//
//  Created by 张晓波 on 6/7/12.
//  Copyright (c) 2012 Ethan. All rights reserved.
//

#import "Notification.h"

@implementation Notification
@synthesize mails;
@synthesize ats;
@synthesize replies;
@synthesize count;
- (id)init
{
    self = [super init];
    if (self) {
        
    }
    return self;
}
@end
