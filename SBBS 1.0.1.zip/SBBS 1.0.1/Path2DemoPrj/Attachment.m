//
//  Attachment.m
//  SBBS-OS-X-Client
//
//  Created by Huang Feiqiao on 13-1-24.
//  Copyright (c) 2013年 Huang Feiqiao. All rights reserved.
//

#import "Attachment.h"

@implementation Attachment
@synthesize attId;
@synthesize attFileName;
@synthesize attPos;
@synthesize attSize;
@synthesize attUrl;
- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here.
    }
    return self;
}
@end
